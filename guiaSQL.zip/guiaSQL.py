# --------------------------------------------------------------
# Laboratorio de Datos - SQL
# Guía de ejercicios - Consultas SQL
# --------------------------------------------------------------
# ******************* Ruz Veloso Luciano ***********************

#%%
# importo bibliotecas necesarias
import pandas as pd
import numpy as np
from inline_sql import sql, sql_val

#%%
# importo las tablas necesarias
casos = pd.read_csv('/home/labo2023/Descargas/casos.csv')
departamento = pd.read_csv('/home/labo2023/Descargas/departamento.csv')
grupoetario = pd.read_csv('/home/labo2023/Descargas/grupoetario.csv')
provincia = pd.read_csv('/home/labo2023/Descargas/provincia.csv')
tipoevento = pd.read_csv('/home/labo2023/Descargas/tipoevento.csv')
#%%

########### Consultas sobre una tabla (A)

### Tabla departamento

# a. Listar sólo los nombres de todos los departamentos que hay en la tabla
#    departamento (dejando los registros repetidos).

departamento_nombres = sql^ """
                        SELECT descripcion
                        FROM departamento
                        """
departamento_nombres

# b. Listar sólo los nombres de todos los departamentos que hay en la tabla
# departamento (eliminando los registros repetidos)

departamento_nombres_sinrep = sql^ """                    
                                SELECT DISTINCT descripcion
                                FROM departamento
                                """
departamento_nombres_sinrep

# c. Listar sólo los códigos de departamento y sus nombres de todos los
# departamentos que hay en la tabla departamento.

depto_id_desc = sql^ """                    
                    SELECT DISTINCT id, descripcion
                    FROM departamento
                    """
depto_id_desc

# d. Listar todas las columnas de la tabla departamento.

depto = sql^ """
             SELECT * FROM departamento
             """
depto             

# e. Listar los códigos de departamento y nombres de todos los departamentos
# que hay en la tabla departamento. Utilizar los siguientes alias para las
# columnas: codigo_depto, nombre_depto

depto = sql^ """
             SELECT id AS codigo_depto,
             descripcion AS nombre_depto
             FROM departamento
             """
depto

# f. Listar los códigos de departamento y sus nombres, ordenados por sus
# nombres de manera descendentes (de la Z a la A). En caso de empate,
# desempatar por código de departamento de manera ascendente.

depto = sql^ """
             SELECT codigo_depto,
             nombre_depto
             FROM depto
             ORDER BY nombre_depto DESC,
             codigo_depto ASC
             """
depto

# g. Listar los registros de la tabla departamento cuyo código de provincia es
# igual a 54

depto = sql^ """
             SELECT * 
             FROM departamento
             WHERE departamento.id_provincia == 54
             """
depto

# h. Listar los registros de la tabla departamento cuyo código de provincia es
# igual a 22, 78 u 86

depto = sql^ """
             SELECT * 
             FROM departamento
             WHERE departamento.id_provincia == 22 OR
             departamento.id_provincia == 78 OR
             departamento.id_provincia == 86
             """
depto

# i. Listar los registros de la tabla departamento cuyos códigos de provincia
# se encuentren entre el 50 y el 59 (ambos valores inclusive)

depto = sql^ """
             SELECT * 
             FROM departamento
             WHERE departamento.id_provincia >= 50 AND
             departamento.id_provincia <= 59
             """
depto

# p. Listar los registros de la tabla departamento cuyos nombres tengan ”san”
# en alguna parte de su nombre. Listar sólo id y descripcion. Utilizar los
# siguientes alias para las columnas: codigo_depto y nombre_depto,
# respectivamente. El resultado debe estar ordenado por sus nombres de
# manera descendentes (de la Z a la A)



#%%
### Tabla provincia

provincia

# j. Listar los registros de la tabla provincia cuyos nombres comiencen con la
# letra M

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE 'M%'
             """
prov

# k. Listar los registros de la tabla provincia cuyos nombres comiencen con la
# letra S y su quinta letra sea una letra A

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE 'S___a%'
             """
prov

# l. Listar los registros de la tabla provincia cuyos nombres terminan con la
# letra A

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE '%a'
             """
prov

# m. Listar los registros de la tabla provincia cuyos nombres tengan
# exactamente 5 letras

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE '_____'
             """
prov

# n. Listar los registros de la tabla provincia cuyos nombres tengan ”do” en
# alguna parte de su nombre

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE '%do%' OR
             provincia.descripcion LIKE 'Do%'
             """
prov


# o. Listar los registros de la tabla provincia cuyos nombres tengan ”do” en
# alguna parte de su nombre y su código sea menor a 30

prov = sql^ """
             SELECT * 
             FROM provincia
             WHERE provincia.descripcion LIKE '%do%' AND
             provincia.id < 30
             """
prov









