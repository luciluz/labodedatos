# --------------------------------------------------------------
# Laboratorio de Datos - SQL
# Guía de ejercicios - Consultas SQL
# --------------------------------------------------------------
# ******************* Ruz Veloso Luciano ***********************

#%%
# importo bibliotecas necesarias
import pandas as pd
import numpy as np
from inline_sql import sql, sql_val

#%%
# importo las tablas necesarias
casos = pd.read_csv('casos.csv')
departamento = pd.read_csv('departamento.csv')
grupoetario = pd.read_csv('grupoetario.csv')
provincia = pd.read_csv('provincia.csv')
tipoevento = pd.read_csv('tipoevento.csv')
#%%

########### Consultas sobre una tabla (A)

# a. Listar sólo los nombres de todos los departamentos que hay en la tabla
#    departamento (dejando los registros repetidos).

departamento_nombres = sql^ """
                        SELECT descripcion
                        FROM departamento
                        """
departamento_nombres

# b. Listar sólo los nombres de todos los departamentos que hay en la tabla
# departamento (eliminando los registros repetidos)

departamento_nombres_sinrep = sql^ """                    
                                SELECT DISTINCT descripcion
                                FROM departamento
                                """
departamento_nombres_sinrep

# c. Listar sólo los códigos de departamento y sus nombres de todos los
# departamentos que hay en la tabla departamento.

depto_id_desc = sql^ """                    
                    SELECT DISTINCT id, descripcion
                    FROM departamento
                    """
depto_id_desc

# Listar todas las columnas de la tabla departamento.

depto = sql^ """
             SELECT * FROM departamento
             """
depto             

